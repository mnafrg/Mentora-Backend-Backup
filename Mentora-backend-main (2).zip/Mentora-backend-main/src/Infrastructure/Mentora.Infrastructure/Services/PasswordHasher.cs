using Mentora.Application.Interfaces;
using Mentora.Infrastructure.Configuration;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;

namespace Mentora.Infrastructure.Services;
public class PasswordHasher : IPasswordHasher
{
    public string HashPassword(string password)
    {
        return BCrypt.Net.BCrypt.HashPassword(password, workFactor: 12);
    }

    public bool VerifyPassword(string password, string passwordHash)
        {
            if (string.IsNullOrEmpty(passwordHash)) return false;

         return BCrypt.Net.BCrypt.Verify(password, passwordHash);

    }

}