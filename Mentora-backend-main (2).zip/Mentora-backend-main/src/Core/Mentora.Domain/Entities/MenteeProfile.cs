﻿using Mentora.Domain.Enums;

namespace Mentora.Domain.Entities;

public class MenteeProfile
{
    public Guid UserId { get; set; }
    public int DomainId { get; set; }
    public CurrentLevel CurrentLevel { get; set; }  
    public EducationStatus EducationStatus { get; set; }  
    public int? CareerGoalId { get; set; }  
    public int? LearningStyleId { get; set; }  
    public string? CountryCode { get; set; }
    public string? ProfilePictureUrl { get; set; }
    public string? Bio { get; set; }
    public bool IsEmailVerified { get; set; }

    // Navigation properties
    public User User { get; set; } = null!;
    public SkillDomain Domain { get; set; } = null!;
    public CareerGoal? CareerGoal { get; set; }
    public LearningStyle? LearningStyle { get; set; }
    public Country? Country { get; set; }

    // Technologies (tools) - 1 to 5 selections
    public ICollection<MenteeInterest> MenteeInterests { get; set; } = new List<MenteeInterest>();

    // Relevant expertise (SubDomains) - Multi-select
    public ICollection<MenteeSubDomain> MenteeSubDomains { get; set; } = new List<MenteeSubDomain>();
    public ICollection<Mentorship> Mentorships { get; set; } = new List<Mentorship>();
    public ICollection<Feedback> FeedbacksGiven { get; set; } = new List<Feedback>();
    
   
}
