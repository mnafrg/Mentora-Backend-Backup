﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mentora.Application.DTOs.Explore
{
    public class ExploreSearchRequest
    {
        public string? SearchQuery { get; set; }
    }
}